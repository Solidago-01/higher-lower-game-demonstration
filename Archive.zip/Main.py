# Higher/Lower
# L Autumn Gnadinger 2024
# Prompt and Assets from Angela Yu's 100 Days of Code
# based on http://www.higherlowergame.com/
# meant to replicate https://appbrewery.github.io/python-day14-demo/
# Demonstrates the following: dictionary handling, scope management, interactive GUI display, list handling

import tkinter as tk
from tkinter import ttk
from art import *
from game_data import *
import random
import time

# Root window
root = tk.Tk()
root.geometry("1100x750")
root.title('Tkinter Grid Layout')
root.resizable(0,0)

# Configure the grid in columns and rows
root.columnconfigure(0, weight=1)

## GAME INIT ##
score = 0

# Defining Person A
rand_person_a = random.randint(1, 49)
person_a_info = [str(data[rand_person_a]["name"]),
                 str(data[rand_person_a]["description"]),
                 str(data[rand_person_a]["country"]),
                 (data[rand_person_a]["follower_count"])]

rand_person_b = random.randint(1, 49)
person_b_info = [str(data[rand_person_b]["name"]),
                 str(data[rand_person_b]["description"]),
                 str(data[rand_person_b]["country"]),
                 (data[rand_person_b]["follower_count"])]

def new_random_people():
    global rand_person_a
    global person_a_info
    rand_person_a = random.randint(1, 49)
    person_a_info = [str(data[rand_person_a]["name"]),
                     str(data[rand_person_a]["description"]),
                     str(data[rand_person_a]["country"]),
                     (data[rand_person_a]["follower_count"])]
    global rand_person_b
    global person_b_info
    rand_person_b = random.randint(1, 49)
    person_b_info = [str(data[rand_person_b]["name"]),
                     str(data[rand_person_b]["description"]),
                     str(data[rand_person_b]["country"]),
                     (data[rand_person_b]["follower_count"])]
    row_two_left.config(text="Compare A: " + person_a_info[0] + ", a " + person_a_info[1] + " from " + person_a_info[2] + ".", font="Courier 20")
    row_four_left.config(text="Against B: " + person_b_info[0] + ", a " + person_b_info[1] + " from " + person_b_info[2] + ".", font="Courier 20")

    if person_a_info[3] > person_b_info[3]:
        global answer
        answer = "A"
    elif person_a_info[3] < person_b_info[3]:
        answer = "B"

def display_result_win():
    # Row 10 Left
    row_ten_left.config(text="That's right!")
    global score
    score += 1
    row_nine_left.config(text = f"Score: {str(score)}")

def display_result_loose():
    # Row 10 Left
    row_ten_left.config(text="Sorry, you loose.")
    global score
    score = 0
    row_nine_left.config(text = f"Score: {str(score)}")

if person_a_info[3] > person_b_info[3]:
    answer = "A"
elif person_a_info[3] < person_b_info[3]:
    answer = "B"

## EVENT MANAGER ## - Comparing player_answer to answer and behaving accordingly
def compare_answer_a():
    player_answer = "A"
    if answer == player_answer:
        print("you're right!")
        display_result_win()
        new_random_people()
    else:
        print("sorry, too bad!")
        display_result_loose()
        new_random_people()

def compare_answer_b():
    player_answer = "B"
    if answer == player_answer:
        print("you're right!")
        display_result_win()
        new_random_people()
    else:
        print("sorry, too bad!")
        display_result_loose()
        new_random_people()

## INITIALIZE GUI ##
# Row One Left
row_one_left = ttk.Label(root, text=logo, font="Courier 20")
row_one_left.grid(column=0, row=0, sticky=tk.NW, padx=5, pady=5)

# Row Two Left
row_two_left = ttk.Label(root, text="Compare A: " + person_a_info[0] + ", a " + person_a_info[1] + " from " + person_a_info[2] + ".", font="Courier 20")
row_two_left.grid(column=0, row=1, sticky=tk.W, padx=0, pady=5)

# Row Three Left
row_three_left = ttk.Label(root, text=vs, font="Courier 20")
row_three_left.grid(column=0, row=2, sticky=tk.W, padx=0, pady=5)

# Row Four Left
row_four_left = ttk.Label(root, text="Against B: " + person_b_info[0] + ", a " + person_b_info[1] + " from " + person_b_info[2] + ".", font="Courier 20")
row_four_left.grid(column=0, row=3, sticky=tk.W, padx=0, pady=5)

# Row five Left
row_five_left = ttk.Label(root, text="Who has more followers?", font="Courier 20")
row_five_left.grid(column=0, row=4, sticky=tk.W, padx=0, pady=5)

# Row Six Left
row_six_left = ttk.Button(root, text="A", command=compare_answer_a)
row_six_left.grid(column=0, row=5, sticky=tk.SW, padx=0, pady=5)

# Row Seven Left
row_seven_left = ttk.Label(root, text="or", font="Courier 20")
row_seven_left.grid(column=0, row=6, sticky=tk.W, padx=0, pady=5)

# Row Eight Left
row_eight_left = ttk.Button(root, text="B", command=compare_answer_b)
row_eight_left.grid(column=0, row=7, sticky=tk.NW, padx=0, pady=5)

# Row Nine Left
row_nine_left = ttk.Label(root, text=f"Score: {str(score)}", font="Courier 20")
row_nine_left.grid(column=0, row=8, sticky=tk.NW, padx=0, pady=5)

# Row 10 Left
row_ten_left = ttk.Label(root, text="", font="Courier 20")
row_ten_left.grid(column=0, row=9, sticky=tk.NW, padx=0, pady=5)

## ACTIVE WINDOW ##
root.mainloop()
